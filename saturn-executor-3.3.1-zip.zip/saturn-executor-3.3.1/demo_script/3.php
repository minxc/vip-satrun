<?php

echo "I am the 3.php, I will comput a+b.\n";

echo ($argv[1] + $argv[2]);

?>