<?php

echo "I am the 2.php, I will throw exception.\n";

throw new Exception("The exception thrown by 2.php");

?>