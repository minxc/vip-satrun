<?php

echo "I am the 1.php!\n";

?>