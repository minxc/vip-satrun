<?php

echo "I am the 4.php, I will sleep 5s.\n";

sleep(5);

echo "I am awaken after 5s. \n"

?>